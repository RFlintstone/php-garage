<!doctype html>
<html>
<head>
    <meta name="author" content="Ruben Flinterman en Kevin van Bommel"
    <meta charset="UTF-8">
    <title>gar-update-auto.php</title>

    <link rel="stylesheet" type="text/css" href="../garage.scss">
    <link href="https://fonts.googleapis.com/css?family=Roboto" rel="stylesheet">
</head>
<body>
<h1>garage update auto </h1>
<p>
Dit formulier wordt gebruikt om autogegevens te wijzigen
</p>
<form action="gar-update-auto2.php" method="post">
    Welk autokenteken wilt u wijzigen?
    <br /><input type="text" name="autoidvak"><br />
    <input type="submit">
</form>
</body>
</html>
