<!doctype html>
<!doctype html>
<html lang="nl">
<head>
    <meta name="author" content="Ruben Flinterman en Kevin van Bommel"
    <meta charset="UTF-8">
    <title>gar-create-auto1.php</title>
    <link rel="stylesheet" type="text/css" href="../garage.scss">
    <link href="https://fonts.googleapis.com/css?family=Roboto" rel="stylesheet">
</head>
<body>
<h1>Garage create auto 1</h1>
<p>
    Dit formulier wordt gebruikt om autogegevens in te voeren
</p>
<form action="gar-create-auto2.php" method="post">
    autokenteken: <input type="text" name="autokentekenvak"> <br/>
    automerk: <input type="text" name="automerkvak"> <br/>
    autotype: <input type="text" name="autotypevak"> <br/>
    autokmstand: <input type="text" name="autokmstandvak"> <br/>
    KlantID/Eigenaar: <input type="text" name="klantidvak"> <br/>
    <input type="submit">
</form>
</body>
</html>