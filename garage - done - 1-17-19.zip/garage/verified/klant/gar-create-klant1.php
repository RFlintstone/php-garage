<!doctype html>
<!doctype html>
<html lang="nl">
<head>
    <meta name="author" content="Ruben Flinterman en Kevin van Bommel"
    <meta charset="UTF-8">
    <title>gar-create-klant1.php</title>
    <link rel="stylesheet" type="text/css" href="../garage.scss">
    <link href="https://fonts.googleapis.com/css?family=Roboto" rel="stylesheet">
</head>
<body>
<h1>Garage create klant 1</h1>
<p>
    Dit formulier wordt gebruikt om klantgegevens in te voeren
</p>
<form action="gar-create-klant2.php" method="post">
    klantnaam: <input type="text" name="klantnaamvak"> <br/>
    klantadres: <input type="text" name="klantadresvak"> <br/>
    klantpostcode: <input type="text" name="klantpostcodevak"> <br/>
    klantplaats: <input type="text" name="klantplaatsvak"> <br/>
    <input type="submit">
</form>
</body>
</html>