<!doctype html>
<html lang="nl">
<head>
    <meta name="author" content="Ruben Flinterman en Kevin van Bommel"
    <meta charset="UTF-8">
    <link rel="stylesheet" type="text/css" href="./verified/garage.scss">
    <link href="https://fonts.googleapis.com/css?family=Roboto" rel="stylesheet">
    <title>login of register.php</title>
</head>
<body>
<ul>
    <li><a href="login.php">Login</a></li>
    <li><a href="register.php">Register</a></li>
</ul>
</body>
</html>